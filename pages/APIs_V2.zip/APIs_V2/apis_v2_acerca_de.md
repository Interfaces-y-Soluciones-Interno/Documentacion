---
title: Connekta - Acerca de APIs Versión dos
keywords: 
last_updated: Febrero 6, 2025
tags: #[getting_started]
#summary: "Inicio del Módulo de administración"
sidebar: APIs_V2_sidebar
permalink: apis_v2_acerca_de.html
folder: APIs_V2
---

## **Descripción:**

En esta sección se describe el manejo de las APIs Versión dos del sistema de integraciones de Siesa.
Todos los ejemplos se realizan en la herramienta Postman.

Postman: es una herramienta utilizada para probar APIs, permitiendo a los desarrolladores enviar peticiones a servicios web y ver las respuestas. (https://www.postman.com) 

Las API que hacen referencia a las consultas dinámicas, tiene tres apartes; la URL Request donde se muestra el tipo de la petición que es GET y se pone un ejemplo del Endpoint, una nota donde se describen algunos aspectos del microservicio y el uso donde se muestran los ejemplos de como utilizar el microservicio.

Al revisar la documentacion en la página, si encuentra un simbolo mas "+" puede dar clic sobre el para ampliar la información y luego aparece el simbolo menos"-". Y en caso de que no quiera ver la información que abrio puede presionar el simbolo menos.

Para ver la documentación seleccione la opción Connekta APIs V2 en el menú de la parte izquierda.
